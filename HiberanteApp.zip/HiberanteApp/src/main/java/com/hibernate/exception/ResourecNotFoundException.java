package com.hibernate.exception;

public class ResourecNotFoundException extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ResourecNotFoundException(String message) {
		super(message);
	}

}
